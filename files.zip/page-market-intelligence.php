<?php
/**
 * Template Name: Market Intelligence
 * Description: SSR template for Autonomous IT Market Intelligence 2025-2030
 * 
 * All content is server-side rendered in the HTML source for SEO.
 * Charts are progressively enhanced via Chart.js after page load.
 */

// Prevent direct access
if (!defined('ABSPATH')) exit;

// ── Data Arrays (update these when new analyst reports publish) ──────────────
$last_updated = '2026-05-12';
$site_url = get_site_url();
$page_url = get_permalink();
$og_image = get_template_directory_uri() . '/assets/img/og-market-intelligence.png';

// Narrow scope (platform-only)
$narrow = [
    ['cat' => 'ITSM + ITOM',            'tam25' => 52,   'tam30' => 94,   'cagr' => 13, 'driver' => 'ServiceNow consolidation + agentic orchestration'],
    ['cat' => 'AIOps & Observability',   'tam25' => 36,   'tam30' => 100,  'cagr' => 22, 'driver' => 'AIOps analytics platforms only'],
    ['cat' => 'RPA & IPA',              'tam25' => 24,   'tam30' => 74,   'cagr' => 25, 'driver' => 'Platform/software only, excl. services'],
    ['cat' => 'SecOps Platform',         'tam25' => 21,   'tam30' => 54,   'cagr' => 21, 'driver' => 'SIEM + SOAR + XDR core stack'],
    ['cat' => 'Agentic AI for IT Ops',   'tam25' => 1.2,  'tam30' => 8,    'cagr' => 45, 'driver' => 'IT slice of horizontal enterprise agents'],
];

// Broad scope (full envelope)
$broad = [
    ['cat' => 'ITSM + ITOM',            'tam25' => 52,   'tam30' => 94,   'cagr' => 13, 'includes' => 'Stable — same envelope in both cuts'],
    ['cat' => 'AIOps & Observability',   'tam25' => 62,   'tam30' => 170,  'cagr' => 22, 'includes' => '+ OTel, APM, log management, data observability'],
    ['cat' => 'RPA & IPA',              'tam25' => 28,   'tam30' => 99,   'cagr' => 29, 'includes' => '+ implementation and managed services'],
    ['cat' => 'SecOps Platform',         'tam25' => 38,   'tam30' => 75,   'cagr' => 15, 'includes' => '+ EDR, NDR, UEBA, threat intelligence'],
    ['cat' => 'Agentic AI for IT Ops',   'tam25' => 3,    'tam30' => 40,   'cagr' => 68, 'includes' => '+ all horizontal enterprise agents touching IT'],
];

$narrow_total_25 = array_sum(array_column($narrow, 'tam25'));
$narrow_total_30 = array_sum(array_column($narrow, 'tam30'));
$broad_total_25 = array_sum(array_column($broad, 'tam25'));
$broad_total_30 = array_sum(array_column($broad, 'tam30'));

// Category deep-dive content
$categories = [
    [
        'id'    => 'aiops-observability',
        'title' => 'AIOps & Observability Platforms',
        'icon'  => '📡',
        'narrow_25' => '$36B', 'narrow_30' => '$100B', 'narrow_cagr' => '22%',
        'broad_25'  => '$62B', 'broad_30'  => '$170B', 'broad_cagr'  => '22%',
        'scope_note' => 'Narrow = AIOps analytics platforms. Broad = full observability envelope including OTel-driven APM, log management, and data observability.',
        'description' => 'The most contested category because analysts draw the boundary differently. Mordor Intelligence sizes AIOps at $18.95B in 2026 growing to $37.79B by 2031. Grand View Research takes a narrower cut at $14.60B in 2024 to $36.07B by 2030. Research & Markets captures the broader AIOps+services envelope at $33.78B in 2025 to $99.07B by 2030. Observability platforms alone are sized at $28.5B in 2025 growing to $172.1B by 2035. The variance reflects whether you count OpenTelemetry-era full-stack observability plus AIOps overlays, or just the AIOps analytics layer.',
        'key_signals' => [
            'Palo Alto Networks / Chronosphere acquisition signals SecOps-Observability convergence',
            'SentinelOne / Observo AI deal extends security into telemetry pipelines',
            'OpenTelemetry becoming the de facto collection standard, shifting TAM toward OTel-native platforms',
            'Datadog, Dynatrace, New Relic expanding into AIOps analytics overlays',
        ],
        'sources' => 'Mordor Intelligence, Grand View Research, Research & Markets, Precedence Research',
    ],
    [
        'id'    => 'itsm-itom',
        'title' => 'IT Service & Operations Management',
        'icon'  => '🔧',
        'narrow_25' => '$52B', 'narrow_30' => '$94B', 'narrow_cagr' => '13%',
        'broad_25'  => '$52B', 'broad_30'  => '$94B', 'broad_cagr'  => '13%',
        'scope_note' => 'Stable envelope — ITSM (~$15B) + ITOM (~$36B) software. Same in both narrow and broad cuts.',
        'description' => 'The most stable and concentrated category. Grand View pegs ITSM at $13.46B in 2024, projected to $29.93B by 2030 at 14.4% CAGR. ITOM is sized by Mordor Intelligence at $36.3B in 2025 forecast to $64.9B by 2030 at 12.30% CAGR. ServiceNow holds roughly 44% ITSM share with top 10 vendors accounting for more than 80% of global revenue — one of the most concentrated enterprise software categories.',
        'key_signals' => [
            'ServiceNow Moveworks acquisition and AI Agent Orchestrator redefine the category',
            'BMC Helix 25.1 with agentic AI capabilities',
            'ITOM includes IT Operations Analytics (growing at 19.50% CAGR) — overlaps significantly with AIOps',
            'Agentic ticket resolution is the first production-grade AI use case in ITSM',
        ],
        'sources' => 'Grand View Research, Mordor Intelligence, MarketsandMarkets, Fortune Business Insights',
    ],
    [
        'id'    => 'rpa-ipa',
        'title' => 'RPA & Intelligent Process Automation',
        'icon'  => '🤖',
        'narrow_25' => '$24B', 'narrow_30' => '$74B', 'narrow_cagr' => '25%',
        'broad_25'  => '$28B', 'broad_30'  => '$99B', 'broad_cagr'  => '29%',
        'scope_note' => 'Narrow = platform/software only. Broad = includes implementation services wrap.',
        'description' => 'Precedence Research puts global RPA at $28.31B in 2025, growing to approximately $247.34B by 2035 at 24.20% CAGR. The critical narrative shift: pure rule-based RPA is being absorbed into agentic automation. Deloitte partnered with UiPath in July 2025 to launch agentic GBS integrating generative AI, workflow orchestration, RPA, and machine learning. UiPath launched its enterprise-grade agentic automation platform with Maestro orchestration in April 2025.',
        'key_signals' => [
            'Category morphing from rule-based RPA into agentic automation — TAM definitions shifting underneath forecast models',
            'UiPath Maestro orchestration platform repositions RPA as AI agent infrastructure',
            'Deloitte-UiPath agentic GBS partnership signals enterprise readiness',
            'Narrow vs. broad spread (~$25B by 2030) reflects services revenue that follows platform adoption',
        ],
        'sources' => 'Precedence Research, Grand View Research, Fortune Business Insights',
    ],
    [
        'id'    => 'agentic-it-ops',
        'title' => 'Agentic AI for IT Operations',
        'icon'  => '🧠',
        'narrow_25' => '$1.2B', 'narrow_30' => '$8B', 'narrow_cagr' => '45%',
        'broad_25'  => '$3B',   'broad_30'  => '$40B', 'broad_cagr'  => '68%',
        'scope_note' => 'Narrow = disciplined carve-out of IT-specific agents. Broad = all horizontal enterprise agents touching IT workflows.',
        'description' => 'The newest and fastest-growing category. Grand View sizes overall enterprise agentic AI at $2.58B in 2024 to $24.50B by 2030 at 46.2% CAGR. MarketsandMarkets projects $40B by 2030 at 47% CAGR. The IT operations slice is much smaller: horizontal enterprise agents in customer operations and IT/security together accounted for $2.18B in 2025, with IT representing roughly half. The strongest ROI is being reported in IT operations (35%) and marketing (30%), and 88% of executives plan to increase AI budgets specifically for agentic AI.',
        'key_signals' => [
            'Fastest-growing category at 45% CAGR (narrow) — did not exist as a named line item two years ago',
            'IT operations showing highest ROI (35%) of any agentic AI use case',
            'Narrow vs. broad spread is the widest (5x) — reflects whether you count just IT agents or all enterprise agents',
            'Vendor taxonomies will keep shifting through 2027 as category boundaries settle',
        ],
        'sources' => 'Grand View Research, MarketsandMarkets, Omdia, Information Matters',
    ],
    [
        'id'    => 'secops-platform',
        'title' => 'Security Operations (SecOps) Platform',
        'icon'  => '🛡️',
        'narrow_25' => '$21B', 'narrow_30' => '$54B', 'narrow_cagr' => '21%',
        'broad_25'  => '$38B', 'broad_30'  => '$75B', 'broad_cagr'  => '15%',
        'scope_note' => 'Narrow = SIEM + SOAR + XDR. Broad = adds EDR, NDR, UEBA, threat intelligence, vulnerability management.',
        'description' => 'The scope question matters most here. Global Growth Insights sizes Security Operations Software at $31.4B in 2025 to $76.2B by 2033 at 11.72% CAGR. Business Research Insights takes a tighter cut at $26.8B in 2024 to $51.68B by 2033. Omdia tracks 10 segments — TH, EDR, NDR, XDR, SIEM, SOAR, RBVM, ASMD, SA & UEBA, and threat intelligence — with forecasts through 2030. The category is being re-segmented: SIEM, SOAR, EDR, XDR, and UEBA are collapsing into unified platforms.',
        'key_signals' => [
            'SIEM/XDR/SOAR collapsing into unified platforms — 10 sub-segments converging',
            'AI SOC startups (Dropzone, Prophet, Radiant, Simbian, Crogl) compete in the narrow SIEM+SOAR+XDR cut',
            'Use narrow for AI SOC disruption thesis; broad for enterprise buyer budget framing',
            'CrowdStrike-Onum deal extends security into data observability',
        ],
        'sources' => 'Global Growth Insights, Business Research Insights, Omdia, MRFR',
    ],
];

get_header();
?>

<!-- JSON-LD Structured Data -->
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": "Autonomous IT Market Intelligence 2025–2030",
    "description": "Executive market intelligence covering AIOps, ITOM, RPA, Agentic Operations, and Security Operations — TAM analysis with narrow and broad scope cuts.",
    "url": "<?php echo esc_url($page_url); ?>",
    "dateModified": "<?php echo $last_updated; ?>",
    "publisher": {
        "@type": "Organization",
        "name": "AI Enterprise IT",
        "url": "<?php echo esc_url($site_url); ?>"
    },
    "about": [
        {"@type": "Thing", "name": "AIOps"},
        {"@type": "Thing", "name": "IT Operations Management"},
        {"@type": "Thing", "name": "Robotic Process Automation"},
        {"@type": "Thing", "name": "Agentic AI"},
        {"@type": "Thing", "name": "Security Operations"}
    ]
}
</script>

<style>
/* ── Base layout ──────────────────────────────────────────────── */
:root {
    --mi-bg: #0F172A;
    --mi-surface: #1E293B;
    --mi-surface-alt: #334155;
    --mi-border: #475569;
    --mi-text: #F1F5F9;
    --mi-text-muted: #94A3B8;
    --mi-accent: #0EA5E9;
    --mi-accent-light: #38BDF8;
    --mi-green: #10B981;
    --mi-amber: #F59E0B;
    --mi-pink: #EC4899;
    --mi-purple: #8B5CF6;
    --mi-red: #EF4444;
    --mi-max-width: 1120px;
}

.mi-page {
    background: var(--mi-bg);
    color: var(--mi-text);
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    line-height: 1.6;
    padding: 0;
    margin: 0;
    -webkit-font-smoothing: antialiased;
}

.mi-page *, .mi-page *::before, .mi-page *::after {
    box-sizing: border-box;
}

.mi-container {
    max-width: var(--mi-max-width);
    margin: 0 auto;
    padding: 0 24px;
}

/* ── Hero ─────────────────────────────────────────────────────── */
.mi-hero {
    padding: 64px 0 48px;
    border-bottom: 1px solid var(--mi-border);
}

.mi-hero h1 {
    font-size: clamp(28px, 4vw, 42px);
    font-weight: 700;
    letter-spacing: -0.02em;
    margin: 0 0 12px;
    color: #fff;
}

.mi-hero .mi-subtitle {
    font-size: 18px;
    color: var(--mi-text-muted);
    margin: 0 0 24px;
    max-width: 640px;
}

.mi-hero .mi-meta {
    font-size: 13px;
    color: var(--mi-text-muted);
    display: flex;
    flex-wrap: wrap;
    gap: 16px;
    align-items: center;
}

.mi-hero .mi-meta span {
    display: flex;
    align-items: center;
    gap: 6px;
}

.mi-badge {
    display: inline-block;
    padding: 3px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.05em;
}

.mi-badge--accent {
    background: rgba(14, 165, 233, 0.15);
    color: var(--mi-accent-light);
}

/* ── KPI cards ────────────────────────────────────────────────── */
.mi-kpi-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 16px;
    padding: 40px 0 32px;
}

.mi-kpi {
    background: var(--mi-surface);
    border: 1px solid var(--mi-border);
    border-radius: 12px;
    padding: 20px;
}

.mi-kpi__label {
    font-size: 12px;
    color: var(--mi-text-muted);
    text-transform: uppercase;
    letter-spacing: 0.06em;
    margin: 0 0 8px;
}

.mi-kpi__value {
    font-size: 28px;
    font-weight: 700;
    color: #fff;
    margin: 0;
}

.mi-kpi__value--accent { color: var(--mi-accent-light); }
.mi-kpi__value--green  { color: var(--mi-green); }
.mi-kpi__value--amber  { color: var(--mi-amber); }
.mi-kpi__value--pink   { color: var(--mi-pink); }

.mi-kpi__note {
    font-size: 12px;
    color: var(--mi-text-muted);
    margin: 4px 0 0;
}

/* ── Section styling ──────────────────────────────────────────── */
.mi-section {
    padding: 48px 0;
    border-bottom: 1px solid rgba(71, 85, 105, 0.5);
}

.mi-section:last-child {
    border-bottom: none;
}

.mi-section__title {
    font-size: 24px;
    font-weight: 600;
    margin: 0 0 8px;
    color: #fff;
}

.mi-section__desc {
    font-size: 15px;
    color: var(--mi-text-muted);
    margin: 0 0 32px;
    max-width: 720px;
}

/* ── Tables ───────────────────────────────────────────────────── */
.mi-table-wrap {
    overflow-x: auto;
    margin: 0 0 24px;
    border-radius: 12px;
    border: 1px solid var(--mi-border);
}

.mi-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 14px;
    min-width: 640px;
}

.mi-table thead {
    background: var(--mi-surface);
}

.mi-table th {
    padding: 14px 16px;
    text-align: left;
    font-weight: 600;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: var(--mi-text-muted);
    border-bottom: 1px solid var(--mi-border);
}

.mi-table th:not(:first-child) {
    text-align: right;
}

.mi-table td {
    padding: 14px 16px;
    border-bottom: 1px solid rgba(71, 85, 105, 0.4);
    color: var(--mi-text);
}

.mi-table td:not(:first-child) {
    text-align: right;
    font-variant-numeric: tabular-nums;
}

.mi-table td:first-child {
    font-weight: 500;
}

.mi-table tbody tr:last-child td {
    border-bottom: none;
}

.mi-table tfoot {
    background: var(--mi-surface);
}

.mi-table tfoot td {
    padding: 14px 16px;
    font-weight: 600;
    border-top: 1px solid var(--mi-border);
    border-bottom: none;
}

/* ── Chart container ──────────────────────────────────────────── */
.mi-chart-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 24px;
    margin: 32px 0;
}

@media (max-width: 768px) {
    .mi-chart-row { grid-template-columns: 1fr; }
}

.mi-chart-box {
    background: var(--mi-surface);
    border: 1px solid var(--mi-border);
    border-radius: 12px;
    padding: 20px;
}

.mi-chart-box__title {
    font-size: 14px;
    font-weight: 600;
    color: var(--mi-text-muted);
    margin: 0 0 16px;
}

.mi-chart-box canvas {
    width: 100% !important;
    height: 280px !important;
}

/* ── Category cards ───────────────────────────────────────────── */
.mi-cat-card {
    background: var(--mi-surface);
    border: 1px solid var(--mi-border);
    border-radius: 12px;
    padding: 28px;
    margin: 0 0 24px;
}

.mi-cat-card__header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin: 0 0 16px;
}

.mi-cat-card__icon {
    font-size: 28px;
    line-height: 1;
}

.mi-cat-card__title {
    font-size: 20px;
    font-weight: 600;
    color: #fff;
    margin: 0;
}

.mi-cat-card__kpis {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
    gap: 12px;
    margin: 0 0 20px;
}

.mi-cat-kpi {
    background: rgba(15, 23, 42, 0.5);
    border-radius: 8px;
    padding: 12px;
}

.mi-cat-kpi__label {
    font-size: 11px;
    color: var(--mi-text-muted);
    text-transform: uppercase;
    letter-spacing: 0.05em;
    margin: 0 0 4px;
}

.mi-cat-kpi__value {
    font-size: 18px;
    font-weight: 600;
    color: var(--mi-accent-light);
}

.mi-cat-card__scope {
    font-size: 13px;
    color: var(--mi-amber);
    background: rgba(245, 158, 11, 0.08);
    border-left: 3px solid var(--mi-amber);
    padding: 10px 14px;
    border-radius: 0 8px 8px 0;
    margin: 0 0 16px;
}

.mi-cat-card__desc {
    font-size: 15px;
    color: var(--mi-text-muted);
    margin: 0 0 16px;
    line-height: 1.7;
}

.mi-cat-card__signals {
    list-style: none;
    padding: 0;
    margin: 0 0 12px;
}

.mi-cat-card__signals li {
    font-size: 14px;
    color: var(--mi-text);
    padding: 6px 0 6px 20px;
    position: relative;
}

.mi-cat-card__signals li::before {
    content: '';
    position: absolute;
    left: 0;
    top: 14px;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: var(--mi-accent);
}

.mi-cat-card__sources {
    font-size: 12px;
    color: var(--mi-text-muted);
    font-style: italic;
}

/* ── Scope comparison boxes ───────────────────────────────────── */
.mi-scope-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
    margin: 32px 0;
}

@media (max-width: 640px) {
    .mi-scope-grid { grid-template-columns: 1fr; }
}

.mi-scope-box {
    border-radius: 12px;
    padding: 20px;
}

.mi-scope-box--narrow {
    background: rgba(139, 92, 246, 0.08);
    border: 1px solid rgba(139, 92, 246, 0.25);
}

.mi-scope-box--broad {
    background: rgba(16, 185, 129, 0.08);
    border: 1px solid rgba(16, 185, 129, 0.25);
}

.mi-scope-box__label {
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    margin: 0 0 8px;
}

.mi-scope-box--narrow .mi-scope-box__label { color: var(--mi-purple); }
.mi-scope-box--broad  .mi-scope-box__label { color: var(--mi-green); }

.mi-scope-box__text {
    font-size: 14px;
    color: var(--mi-text-muted);
    line-height: 1.6;
    margin: 0;
}

/* ── Methodology / footer ─────────────────────────────────────── */
.mi-methodology {
    background: var(--mi-surface);
    border: 1px solid var(--mi-border);
    border-radius: 12px;
    padding: 24px;
    margin: 32px 0 0;
}

.mi-methodology__title {
    font-size: 16px;
    font-weight: 600;
    color: #fff;
    margin: 0 0 12px;
}

.mi-methodology__text {
    font-size: 14px;
    color: var(--mi-text-muted);
    line-height: 1.7;
    margin: 0;
}

.mi-footer {
    padding: 32px 0;
    text-align: center;
    font-size: 13px;
    color: var(--mi-text-muted);
}
</style>

<div class="mi-page">
<div class="mi-container">

    <!-- ════ HERO ════ -->
    <header class="mi-hero">
        <span class="mi-badge mi-badge--accent">2025–2030 analysis</span>
        <h1>Autonomous IT market intelligence</h1>
        <p class="mi-subtitle">
            TAM analysis across five categories — AIOps, ITSM/ITOM, RPA, Agentic IT Ops, and SecOps — 
            with narrow (platform-only) and broad (full envelope) scope cuts for different use cases.
        </p>
        <div class="mi-meta">
            <span>Last updated: <?php echo date('F j, Y', strtotime($last_updated)); ?></span>
            <span>|</span>
            <span>Sources: Mordor Intelligence, Grand View Research, MarketsandMarkets, Omdia, Precedence Research</span>
        </div>
    </header>

    <!-- ════ KPI SUMMARY ════ -->
    <div class="mi-kpi-grid">
        <div class="mi-kpi">
            <p class="mi-kpi__label">Narrow 2025 TAM</p>
            <p class="mi-kpi__value mi-kpi__value--accent">~$<?php echo number_format($narrow_total_25, 1); ?>B</p>
            <p class="mi-kpi__note">Platform-only scope</p>
        </div>
        <div class="mi-kpi">
            <p class="mi-kpi__label">Narrow 2030 TAM</p>
            <p class="mi-kpi__value mi-kpi__value--accent">~$<?php echo number_format($narrow_total_30, 1); ?>B</p>
        </div>
        <div class="mi-kpi">
            <p class="mi-kpi__label">Broad 2025 TAM</p>
            <p class="mi-kpi__value mi-kpi__value--green">~$<?php echo number_format($broad_total_25, 1); ?>B</p>
            <p class="mi-kpi__note">Full envelope scope</p>
        </div>
        <div class="mi-kpi">
            <p class="mi-kpi__label">Broad 2030 TAM</p>
            <p class="mi-kpi__value mi-kpi__value--green">~$<?php echo number_format($broad_total_30, 1); ?>B</p>
        </div>
        <div class="mi-kpi">
            <p class="mi-kpi__label">Scope delta 2030</p>
            <p class="mi-kpi__value mi-kpi__value--amber">~$<?php echo number_format($broad_total_30 - $narrow_total_30, 0); ?>B</p>
            <p class="mi-kpi__note">Where category boundaries shift</p>
        </div>
        <div class="mi-kpi">
            <p class="mi-kpi__label">Fastest growing</p>
            <p class="mi-kpi__value mi-kpi__value--pink">Agentic IT</p>
            <p class="mi-kpi__note">~45% CAGR (narrow)</p>
        </div>
    </div>

    <!-- ════ SCOPE COMPARISON ════ -->
    <section class="mi-section" id="scope-comparison">
        <h2 class="mi-section__title">Narrow vs. broad scope</h2>
        <p class="mi-section__desc">
            Every TAM number in Autonomous IT depends on where you draw the category boundary. 
            We present both cuts so you can choose the right framing for your audience.
        </p>

        <div class="mi-scope-grid">
            <div class="mi-scope-box mi-scope-box--narrow">
                <p class="mi-scope-box__label">Narrow cut — when to use</p>
                <p class="mi-scope-box__text">
                    AI SOC disruption thesis, vendor competitive analysis, isolating the displaceable market. 
                    Strips out commoditized adjacencies like EDR, NDR, managed services, broader observability tooling.
                </p>
            </div>
            <div class="mi-scope-box mi-scope-box--broad">
                <p class="mi-scope-box__label">Broad cut — when to use</p>
                <p class="mi-scope-box__text">
                    Buyer-budget framing, CIO decks, platform consolidation narratives. 
                    Reflects how enterprises actually line-item spend across telemetry, security, and service management.
                </p>
            </div>
        </div>

        <!-- Narrow table (SSR — visible before JS) -->
        <h3 style="font-size:16px; font-weight:600; color:var(--mi-text-muted); margin:32px 0 12px;">Narrow scope (platform-only)</h3>
        <div class="mi-table-wrap">
            <table class="mi-table">
                <thead>
                    <tr>
                        <th>Category</th>
                        <th>2025 TAM</th>
                        <th>2030 TAM</th>
                        <th>CAGR</th>
                        <th>Scope basis</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($narrow as $row): ?>
                    <tr>
                        <td><?php echo esc_html($row['cat']); ?></td>
                        <td>$<?php echo number_format($row['tam25'], 1); ?>B</td>
                        <td>$<?php echo number_format($row['tam30'], 1); ?>B</td>
                        <td><?php echo $row['cagr']; ?>%</td>
                        <td style="text-align:left; font-size:12px; color:var(--mi-text-muted);"><?php echo esc_html($row['driver']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td>Combined</td>
                        <td>~$<?php echo number_format($narrow_total_25, 1); ?>B</td>
                        <td>~$<?php echo number_format($narrow_total_30, 1); ?>B</td>
                        <td>~20%</td>
                        <td></td>
                    </tr>
                </tfoot>
            </table>
        </div>

        <!-- Broad table -->
        <h3 style="font-size:16px; font-weight:600; color:var(--mi-text-muted); margin:32px 0 12px;">Broad scope (full envelope)</h3>
        <div class="mi-table-wrap">
            <table class="mi-table">
                <thead>
                    <tr>
                        <th>Category</th>
                        <th>2025 TAM</th>
                        <th>2030 TAM</th>
                        <th>CAGR</th>
                        <th>What changes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($broad as $row): ?>
                    <tr>
                        <td><?php echo esc_html($row['cat']); ?></td>
                        <td>$<?php echo number_format($row['tam25'], 1); ?>B</td>
                        <td>$<?php echo number_format($row['tam30'], 1); ?>B</td>
                        <td><?php echo $row['cagr']; ?>%</td>
                        <td style="text-align:left; font-size:12px; color:var(--mi-text-muted);"><?php echo esc_html($row['includes']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td>Combined</td>
                        <td>~$<?php echo number_format($broad_total_25, 1); ?>B</td>
                        <td>~$<?php echo number_format($broad_total_30, 1); ?>B</td>
                        <td>~20%</td>
                        <td></td>
                    </tr>
                </tfoot>
            </table>
        </div>

        <!-- Charts (progressive enhancement — JS renders after HTML) -->
        <div class="mi-chart-row">
            <div class="mi-chart-box">
                <p class="mi-chart-box__title">2030 TAM: narrow vs. broad</p>
                <canvas id="mi-chart-scope" aria-label="Bar chart comparing narrow and broad 2030 TAM across five categories"></canvas>
            </div>
            <div class="mi-chart-box">
                <p class="mi-chart-box__title">CAGR by category (narrow scope)</p>
                <canvas id="mi-chart-cagr" aria-label="Horizontal bar chart of CAGR for five Autonomous IT categories"></canvas>
            </div>
        </div>
    </section>

    <!-- ════ CATEGORY DEEP DIVES ════ -->
    <section class="mi-section" id="categories">
        <h2 class="mi-section__title">Category deep dives</h2>
        <p class="mi-section__desc">
            Each category includes narrow and broad TAM, key market signals, and source citations.
        </p>

        <?php foreach ($categories as $cat): ?>
        <article class="mi-cat-card" id="<?php echo esc_attr($cat['id']); ?>">
            <div class="mi-cat-card__header">
                <span class="mi-cat-card__icon"><?php echo $cat['icon']; ?></span>
                <h3 class="mi-cat-card__title"><?php echo esc_html($cat['title']); ?></h3>
            </div>
            <div class="mi-cat-card__kpis">
                <div class="mi-cat-kpi">
                    <p class="mi-cat-kpi__label">Narrow 2025</p>
                    <p class="mi-cat-kpi__value"><?php echo $cat['narrow_25']; ?></p>
                </div>
                <div class="mi-cat-kpi">
                    <p class="mi-cat-kpi__label">Narrow 2030</p>
                    <p class="mi-cat-kpi__value"><?php echo $cat['narrow_30']; ?></p>
                </div>
                <div class="mi-cat-kpi">
                    <p class="mi-cat-kpi__label">Broad 2025</p>
                    <p class="mi-cat-kpi__value"><?php echo $cat['broad_25']; ?></p>
                </div>
                <div class="mi-cat-kpi">
                    <p class="mi-cat-kpi__label">Broad 2030</p>
                    <p class="mi-cat-kpi__value"><?php echo $cat['broad_30']; ?></p>
                </div>
                <div class="mi-cat-kpi">
                    <p class="mi-cat-kpi__label">CAGR (narrow)</p>
                    <p class="mi-cat-kpi__value"><?php echo $cat['narrow_cagr']; ?></p>
                </div>
            </div>
            <div class="mi-cat-card__scope">
                <?php echo esc_html($cat['scope_note']); ?>
            </div>
            <p class="mi-cat-card__desc"><?php echo esc_html($cat['description']); ?></p>
            <h4 style="font-size:14px; font-weight:600; color:var(--mi-accent-light); margin:0 0 8px;">Key market signals</h4>
            <ul class="mi-cat-card__signals">
                <?php foreach ($cat['key_signals'] as $signal): ?>
                <li><?php echo esc_html($signal); ?></li>
                <?php endforeach; ?>
            </ul>
            <p class="mi-cat-card__sources">Sources: <?php echo esc_html($cat['sources']); ?></p>
        </article>
        <?php endforeach; ?>
    </section>

    <!-- ════ SCOPE ARBITRAGE ════ -->
    <section class="mi-section" id="scope-arbitrage">
        <h2 class="mi-section__title">The scope arbitrage zone</h2>
        <p class="mi-section__desc">
            The ~$<?php echo number_format($broad_total_30 - $narrow_total_30, 0); ?>B delta between narrow and broad 2030 TAM 
            is where category definitions are actively shifting.
        </p>
        <div class="mi-methodology">
            <h3 class="mi-methodology__title">Why scope cuts matter</h3>
            <p class="mi-methodology__text">
                Observability platforms are absorbing AIOps. SecOps is absorbing telemetry pipelines. 
                Agentic AI is absorbing RPA. ITSM is extending into ITOM and AIOps via ServiceNow's AI Agent Orchestrator.
                The clean TAM charts are a 2024-era artifact — by 2027 the analyst houses will be forced to re-cut.
                Whichever platforms own "AI-native ITOM" and "unified SecOps" by 2027 capture both pools.
            </p>
        </div>
    </section>

    <!-- ════ METHODOLOGY ════ -->
    <section class="mi-section" id="methodology">
        <h2 class="mi-section__title">Methodology</h2>
        <div class="mi-methodology">
            <h3 class="mi-methodology__title">Source triangulation</h3>
            <p class="mi-methodology__text">
                Each category is sized using 3–5 independent analyst sources (Mordor Intelligence, Grand View Research, 
                MarketsandMarkets, Precedence Research, Omdia, Global Growth Insights, Fortune Business Insights, 
                Business Research Insights, MRFR, Information Matters). We take the midpoint of credible estimates 
                after normalizing for scope differences. Narrow and broad cuts are not different sources — they 
                reflect different category boundary definitions applied to the same underlying data.
                All figures are in USD. 2025 is the base year; 2030 is the projection year. CAGRs are calculated 
                from the midpoint estimates. Numbers are rounded and should be treated as order-of-magnitude guidance, 
                not precision forecasts.
            </p>
        </div>
    </section>

    <!-- ════ FOOTER ════ -->
    <footer class="mi-footer">
        <p>&copy; <?php echo date('Y'); ?> aienterpriseit.com — Autonomous IT Market Intelligence</p>
        <p style="margin:8px 0 0;">Data last refreshed: <?php echo date('F j, Y', strtotime($last_updated)); ?></p>
    </footer>

</div><!-- .mi-container -->

<!-- ════ CHART.JS (progressive enhancement) ════ -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var labels = <?php echo json_encode(array_column($narrow, 'cat')); ?>;
    var narrow30 = <?php echo json_encode(array_column($narrow, 'tam30')); ?>;
    var broad30  = <?php echo json_encode(array_column($broad, 'tam30')); ?>;
    var cagrs    = <?php echo json_encode(array_column($narrow, 'cagr')); ?>;

    var chartDefaults = {
        color: '#94A3B8',
        borderColor: 'rgba(71,85,105,0.4)',
        font: { family: 'Inter, sans-serif', size: 11 }
    };
    Chart.defaults.color = chartDefaults.color;
    Chart.defaults.borderColor = chartDefaults.borderColor;

    /* Scope comparison bar chart */
    var ctxScope = document.getElementById('mi-chart-scope');
    if (ctxScope) {
        new Chart(ctxScope, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [
                    { label: 'Narrow 2030', data: narrow30, backgroundColor: '#8B5CF6', borderRadius: 4 },
                    { label: 'Broad 2030',  data: broad30,  backgroundColor: '#10B981', borderRadius: 4 }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom', labels: { padding: 16, usePointStyle: true, pointStyle: 'rectRounded' } },
                    tooltip: { callbacks: { label: function(c) { return c.dataset.label + ': $' + c.parsed.y + 'B'; } } }
                },
                scales: {
                    x: { ticks: { font: { size: 10 } }, grid: { display: false } },
                    y: { ticks: { callback: function(v) { return '$' + v + 'B'; } } }
                }
            }
        });
    }

    /* CAGR horizontal bar */
    var ctxCagr = document.getElementById('mi-chart-cagr');
    if (ctxCagr) {
        new Chart(ctxCagr, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'CAGR 2025-2030',
                    data: cagrs,
                    backgroundColor: cagrs.map(function(v) { return v >= 40 ? '#EC4899' : v >= 20 ? '#8B5CF6' : '#475569'; }),
                    borderRadius: 4
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: { callbacks: { label: function(c) { return c.parsed.x + '% CAGR'; } } }
                },
                scales: {
                    x: { max: 55, ticks: { callback: function(v) { return v + '%'; } } },
                    y: { grid: { display: false }, ticks: { font: { size: 10 } } }
                }
            }
        });
    }
});
</script>
</div><!-- .mi-page -->

<?php get_footer(); ?>
